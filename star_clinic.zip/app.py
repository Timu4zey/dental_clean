
from flask import Flask, render_template, request, redirect, flash, session
import json
import os
import requests
from datetime import datetime
import random

app = Flask(__name__)
app.secret_key = 'supersecretkey'

DATA_FILE = 'appointments.json'
time_slots = ["09:00", "10:00", "11:00", "13:00", "14:00", "15:00"]

TELEGRAM_TOKEN = 'YOUR_TELEGRAM_BOT_TOKEN'
TELEGRAM_CHAT_ID = 'YOUR_TELEGRAM_CHAT_ID'
SMS_API_URL = 'https://api.opersms.uz/send'
SMS_API_KEY = 'YOUR_OPERSMS_API_KEY'

doctors = ["Зиеда", "Ф"]

ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD = 'admin123'

def load_appointments():
    if not os.path.exists(DATA_FILE):
        return {"appointments": []}
    try:
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except:
        return {"appointments": []}

def save_appointments(data):
    with open(DATA_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

def send_sms_code(phone, code):
    payload = {
        "apiKey": SMS_API_KEY,
        "number": phone,
        "message": f"Код подтверждения: {code}"
    }
    try:
        response = requests.post(SMS_API_URL, json=payload)
        print("SMS API ответ:", response.text)
    except Exception as e:
        print("Ошибка при отправке SMS:", e)

def send_to_telegram(data):
    text = (
        f"Новая запись:\n"
        f"{data['name']} {data['surname']}\n"
        f"{data['phone']}\n"
        f"{data['doctor']}\n"
        f"{data['date']} в {data['time']}\n"
        f"{data['reason']}"
    )
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    payload = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": text,
        "parse_mode": "HTML"
    }
    try:
        requests.post(url, data=payload)
    except Exception as e:
        print("Ошибка при отправке в Telegram:", e)

@app.route('/', methods=['GET', 'POST'])
def form():
    today = datetime.today().strftime('%Y-%m-%d')
    if request.method == 'POST':
        step = request.form.get('step')

        if step == 'form':
            name = request.form['name']
            surname = request.form['surname']
            phone = request.form['phone']
            doctor = request.form['doctor']
            date = request.form['date']
            time = request.form['time']
            reason = request.form['reason']

            if not phone.startswith('+998') or len(phone) != 13:
                flash("Введите корректный номер телефона")
                return redirect('/')

            session['appointment'] = {
                "name": name,
                "surname": surname,
                "phone": phone,
                "doctor": doctor,
                "date": date,
                "time": time,
                "reason": reason
            }

            code = str(random.randint(1000, 9999))
            session['verification_code'] = code
            send_sms_code(phone, code)

            return render_template('index.html', step='verify', today=today,
                                   doctors=doctors, time_slots=time_slots)

        elif step == 'verify':
            input_code = request.form.get('code')
            if input_code == session.get('verification_code'):
                data = load_appointments()
                form_data = session['appointment']

                for appt in data["appointments"]:
                    if appt["doctor"] == form_data["doctor"] and appt["date"] == form_data["date"] and appt["time"] == form_data["time"]:
                        flash("Это время уже занято")
                        return redirect('/')

                data["appointments"].append(form_data)
                save_appointments(data)
                send_to_telegram(form_data)

                session.pop('appointment', None)
                session.pop('verification_code', None)

                flash("Вы успешно записались!")
                return redirect('/')
            else:
                flash("Неверный код. Попробуйте ещё раз.")
                return render_template('index.html', step='verify', today=today,
                                       doctors=doctors, time_slots=time_slots)

    return render_template('index.html', doctors=doctors, time_slots=time_slots, today=today, step='form')

@app.route('/api/available_times')
def available_times():
    doctor = request.args.get("doctor")
    date = request.args.get("date")
    data = load_appointments()
    taken = [appt["time"] for appt in data["appointments"] if appt["doctor"] == doctor and appt["date"] == date]
    available = [t for t in time_slots if t not in taken]
    return json.dumps(available, ensure_ascii=False)

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session['admin'] = True
            return redirect('/admin')
        else:
            flash("Неверный логин или пароль")
    return render_template('admin_login.html')

@app.route('/admin')
def admin_panel():
    if not session.get('admin'):
        return redirect('/admin/login')
    data = load_appointments()
    return render_template('admin.html', appointments=data['appointments'])

@app.route('/admin/delete/<int:index>', methods=['POST'])
def delete_appointment(index):
    if not session.get('admin'):
        return redirect('/admin/login')
    data = load_appointments()
    if 0 <= index < len(data['appointments']):
        deleted = data['appointments'].pop(index)
        save_appointments(data)
        flash(f"Удалена запись: {deleted['name']} {deleted['surname']}")
    return redirect('/admin')

@app.route('/admin/logout')
def admin_logout():
    session.pop('admin', None)
    return redirect('/admin/login')

if __name__ == '__main__':
    app.run(debug=True)
